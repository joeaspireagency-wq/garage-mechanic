# Hale Motor Works – garage & mobile mechanic website prototype

A single, self-contained HTML page (no build tooling, no external requests apart from Google Fonts).
Fictional business (Armley, Leeds). All prices, reviews, ratings and credentials are placeholders.

## Use
- Open `index.html` in a browser, or host it as-is (GitHub Pages: Settings → Pages → deploy from `main` / root).

## Edit
Source lives in `src/`:
- `a-head.html` – `<head>`, CSS (design tokens at the top)
- `b-body.html` – page markup
- `c-data.js` – site content (services, FAQs, reviews, areas, phone) and image registry
- `d-app.js` – behaviour (quote form + mocked connector, modal, carousel, slider, FAQ, header/bar)
- `*.b64` – inlined photos (hero, van, owner, brake before/after, review badge)

Rebuild after editing: `python3 build.py`  → regenerates `index.html`.

## Notes
- One conversion goal: **Get Your Free Quote**. The quote form is a typed, mocked connector – it sends nothing.
- The review badge and WhatsApp/phone details are placeholders – check before going live.
