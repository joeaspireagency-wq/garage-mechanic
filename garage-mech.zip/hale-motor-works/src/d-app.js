
/* ==========================================================================
   3. TYPED QUOTE CONNECTOR  (src/lib/quote-connector.ts equivalent)
   Mocked, production-shaped. Never throws to the UI, never sends, stores or
   logs personal data: everything stays in this browser tab's memory.

   Types (written as JSDoc so they transfer 1:1 to TypeScript + zod):

   @typedef {'mot'|'service'|'brakes'|'diagnostics'|'clutch'|'battery'|'unsure'} ServiceType
   @typedef {'garage'|'mobile'} ServiceLocation
   @typedef {'next'|'week'|'flexible'} PreferredDay
   @typedef {Object} QuoteRequest
   @property {string} reg                  UK reg, lenient: 2-8 letters/digits
   @property {string=} mileage             optional, digits only
   @property {ServiceType} serviceType
   @property {ServiceLocation} serviceLocation
   @property {string=} postcode            required only when serviceLocation === 'mobile'
   @property {PreferredDay} preferredDay
   @property {string=} note                optional, max 500 chars
   @property {string} name
   @property {string} mobile               UK mobile
   @property {string=} email               optional
   @property {true} consent                must be true
   @property {string=} packageInterest     optional, set by the pricing cards

   @typedef {{status:'success', reference:string, receivedAt:string}} QuoteSuccess
   @typedef {{status:'validation_error', fieldErrors:Record<string,string[]>}} QuoteValidationError
   @typedef {{status:'network_error', message:string, retryable:boolean}} QuoteNetworkError
   @typedef {QuoteSuccess|QuoteValidationError|QuoteNetworkError} QuoteResult   // discriminated union on `status`

   TypeScript/zod version of the schema below:
     export const QuoteRequestSchema = z.object({ reg: z.string().transform(normReg).pipe(z.string().regex(/^[A-Z0-9]{2,8}$/)),
       ..., consent: z.literal(true) }).superRefine((d, ctx) => { if (d.serviceLocation === 'mobile' && !d.postcode) ctx.addIssue({...}) });
   ========================================================================== */
const QuoteRequestSchema = (() => {
  const SERVICES = SITE.serviceTypes.map(s => s.v);
  const GARAGE_ONLY = SITE.serviceTypes.filter(s => s.garageOnly).map(s => s.v);
  const normReg = s => String(s ?? '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  const POSTCODE = /^[A-Z]{1,2}\d[A-Z\d]?\s?\d[A-Z]{2}$/i;
  const EMAIL = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  const cleanPhone = s => String(s ?? '').replace(/[\s\-()]/g, '');

  function safeParse(input) {
    const e = {}; const add = (k, m) => (e[k] ||= []).push(m);
    const d = input && typeof input === 'object' ? input : {};
    const reg = normReg(d.reg);
    if (!reg) add('reg', 'Enter your registration, for example LS16 ABC.');
    else if (!/^[A-Z0-9]{2,8}$/.test(reg)) add('reg', "That doesn't look like a UK reg. Try something like LS16 ABC.");
    const mileage = String(d.mileage ?? '').replace(/[,\s]/g, '');
    if (mileage && !/^\d{1,6}$/.test(mileage)) add('mileage', 'Use numbers only, for example 68000.');
    if (!SERVICES.includes(d.serviceType)) add('serviceType', 'Choose what you need, or pick "Not sure".');
    if (!['garage', 'mobile'].includes(d.serviceLocation)) add('serviceLocation', 'Choose where you would like the work done.');
    if (d.serviceLocation === 'mobile' && GARAGE_ONLY.includes(d.serviceType)) add('serviceLocation', 'This one is done at our garage.');
    const postcode = String(d.postcode ?? '').trim();
    if (d.serviceLocation === 'mobile') {
      if (!postcode) add('postcode', 'Enter the postcode where we should come.');
      else if (!POSTCODE.test(postcode)) add('postcode', "That doesn't look like a UK postcode. Try LS12 3AB.");
    }
    if (!['next', 'week', 'flexible'].includes(d.preferredDay)) add('preferredDay', 'Choose a day.');
    const note = String(d.note ?? '');
    if (note.length > 500) add('note', 'Please keep notes under 500 characters.');
    const name = String(d.name ?? '').trim();
    if (name.length < 2) add('name', 'Enter your name so we know who to ask for.');
    else if (name.length > 80) add('name', 'That name is a bit long. Please shorten it.');
    const mob = cleanPhone(d.mobile);
    if (!mob) add('mobile', 'Enter a mobile number so we can call you.');
    else if (!/^(?:\+?44|0)7\d{9}$/.test(mob)) add('mobile', 'Enter a UK mobile number, for example 07700 900123.');
    const email = String(d.email ?? '').trim();
    if (email && !EMAIL.test(email)) add('email', 'That email looks incomplete. You can also leave it blank.');
    if (d.consent !== true) add('consent', 'Please tick the box so we can respond to your enquiry.');
    if (Object.keys(e).length) return { success: false, error: { fieldErrors: e } };
    return { success: true, data: { reg, mileage: mileage || undefined, serviceType: d.serviceType, serviceLocation: d.serviceLocation,
      postcode: d.serviceLocation === 'mobile' ? postcode.toUpperCase() : undefined, preferredDay: d.preferredDay, note: note.trim() || undefined,
      name, mobile: mob, email: email || undefined, consent: true, packageInterest: d.packageInterest || undefined } };
  }
  return { safeParse, normReg };
})();

/** @param {QuoteRequest} data  @returns {Promise<QuoteResult>} */
async function submitQuote(data) {
  try {
    const parsed = QuoteRequestSchema.safeParse(data);
    if (!parsed.success) return { status: 'validation_error', fieldErrors: parsed.error.fieldErrors };

    /* ---- WHERE THE REAL INTEGRATION PLUGS IN --------------------------------
       1) Quote endpoint (form service, CRM or your own API route):
            const res = await fetch('/api/quote', { method: 'POST',
              headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(parsed.data) });
            if (!res.ok) return { status: 'network_error', message: 'Server said no', retryable: res.status >= 500 };
            const { reference } = await res.json();
       2) Vehicle lookups, server-side only (keys must never reach the browser):
            DVLA Vehicle Enquiry Service (make, colour, MOT status, tax) and the
            DVSA MOT history API (previous advisories). Call them from /api/quote
            using parsed.data.reg, then attach the result to the CRM record.
       In this prototype NOTHING is sent, stored or logged. We only simulate latency.
       Demo hook: put "#demo-error" in the note field to see the error + retry state
       once (the second attempt succeeds).
       ------------------------------------------------------------------------ */
    await new Promise(r => setTimeout(r, 1100 + Math.random() * 500));
    if ((parsed.data.note || '').includes('#demo-error') && !submitQuote._failed) {
      submitQuote._failed = true;
      return { status: 'network_error', message: "We couldn't reach the server just now. Your answers are still here, nothing was lost.", retryable: true };
    }
    const reference = 'HMW-' + Math.random().toString(36).slice(2, 7).toUpperCase();
    return { status: 'success', reference, receivedAt: new Date().toISOString() };
  } catch (err) {
    return { status: 'network_error', message: 'Something went wrong on our side. Please try again.', retryable: true };
  }
}

/* ==========================================================================
   4. UI helpers
   ========================================================================== */
const $ = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => [...r.querySelectorAll(s)];
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const ico = (n, cls = '') => `<svg class="ico ${cls}" aria-hidden="true" focusable="false"><use href="#i-${n}"/></svg>`;
const reduceMotion = () => matchMedia('(prefers-reduced-motion: reduce)').matches;
const rng = seed => () => { seed |= 0; seed = seed + 0x6D2B79F5 | 0; let t = Math.imul(seed ^ seed >>> 15, 1 | seed); t = t + Math.imul(t ^ t >>> 7, 61 | t) ^ t; return ((t ^ t >>> 14) >>> 0) / 4294967296; };

/* ---------- render data-driven sections ---------- */
function renderStatic() {
  $$('[data-img]').forEach(el => { const im = IMAGES[el.dataset.img]; if (im) el.innerHTML = im.render(); });


  $('#symGrid').innerHTML = SITE.symptoms.map((s, i) => `
    <button type="button" class="sym rv" style="--d:${i * 0.05}s" data-quote data-service="${s.service}">
      <span class="ic">${ico(s.icon)}</span>
      <span class="tx"><span class="h">${esc(s.title)}</span><span class="p">${esc(s.text)}</span></span>
      ${ico('right', 'go')}
    </button>`).join('');

  $('#svcGrid').innerHTML = SITE.services.map((s, i) => `
    <article class="svc rv${s.mobile ? ' mob' : ''}" style="--d:${(i % 3) * 0.06}s">
      <div class="svc-top"><span class="ic">${ico(s.icon, '')}</span><span class="tag">${s.tagIcon ? ico(s.tagIcon) : ''}${esc(s.tag)}</span></div>
      <h3>${esc(s.title)}</h3>
      <p class="ben">${esc(s.benefit)}</p>
      <ul class="ticks">${s.features.map(f => `<li>${ico('check')}<span>${esc(f)}</span></li>`).join('')}</ul>
      ${s.note ? `<p class="fine" style="font-size:12.5px">${esc(s.note)}</p>` : ''}
      <div class="from">${s.quoted ? `<b style="font-size:1.5rem">${esc(s.quoted)}</b>` : `from <b>${esc(s.from)}</b>${s.unit ? `<span style="text-transform:none;letter-spacing:0;font-family:var(--font-b);font-weight:500;font-size:13px">${esc(s.unit)}</span>` : ''}`}</div>
    </article>`).join('');

  $('#inclList').innerHTML = SITE.included.map(t => `<li>${ico('check')}<span>${esc(t)}</span></li>`).join('');





  $('#areaGrid').innerHTML = SITE.areas.map(a => `<span class="area">${ico('pin')}${esc(a)}</span>`).join('');

  const star5 = `<span class="stars" role="img" aria-label="5 out of 5 stars">${ico('star').repeat(5)}</span>`;
  $('#track').innerHTML = SITE.reviews.map((r, i) => `
    <article class="rev" aria-roledescription="slide" aria-label="Review ${i + 1} of ${SITE.reviews.length}">
      ${star5}
      <blockquote>"${esc(r.text)}"</blockquote>
      <div class="who"><span class="av" aria-hidden="true">${esc(r.name.split(' ').map(w => w[0]).join('').toUpperCase())}</span><div><b>${esc(r.name)}</b><span>${esc(r.town)}</span></div></div>
      <div class="tags"><span class="tag">${esc(r.job)}</span><span class="tag solid">${r.where === 'Mobile' ? ico('van') : ''}${esc(r.where)}</span></div>
    </article>`).join('');

  $('#faqList').innerHTML = SITE.faqs.map((f, i) => `
    <div class="qa${i === 0 ? ' open' : ''}">
      <h3><button type="button" id="q${i}" aria-expanded="${i === 0}" aria-controls="a${i}"><span>${esc(f.q)}</span>${ico('down')}</button></h3>
      <div class="ans" id="a${i}" role="region" aria-labelledby="q${i}"><div><p>${esc(f.a)}</p></div></div>
    </div>`).join('');
}

/* ---------- CTA buttons: glow structure + cursor-follow ---------- */
function enhanceCTAs() {
  $$('.cta').forEach(b => {
    if (b.querySelector('.cta-label')) return;
    b.innerHTML = `<span class="cta-glow" aria-hidden="true"></span><span class="cta-label">${b.innerHTML}</span>`;
  });
}
document.addEventListener('pointermove', e => {
  if (e.pointerType !== 'mouse' || reduceMotion()) return;
  const b = e.target.closest && e.target.closest('.cta'); if (!b) return;
  const r = b.getBoundingClientRect(); b.style.setProperty('--x', (e.clientX - r.left) + 'px'); b.style.setProperty('--y', (e.clientY - r.top) + 'px');
});
document.addEventListener('pointerout', e => { const b = e.target.closest && e.target.closest('.cta'); if (b) { b.style.removeProperty('--x'); b.style.removeProperty('--y'); } });

/* ---------- ambient background shapes ---------- */
function buildAmbient() {
  const mobile = matchMedia('(max-width:640px)').matches;
  $$('.ambient').forEach((el, idx) => {
    const dark = el.dataset.variant === 'dark', high = el.dataset.density === 'high', r = rng(1000 + idx * 97);
    const circles = high ? (mobile ? 4 : 8) : (mobile ? 1 : 2), lines = high ? (mobile ? 2 : 4) : 1;
    if (high) el.classList.add('high');
    const colour = k => dark
      ? (k % 2 ? `rgba(255,255,255,${(.04 + r() * .04).toFixed(3)})` : `rgba(220,38,38,${(.08 + r() * .07).toFixed(3)})`)
      : (k % 2 ? `rgba(220,38,38,${(.04 + r() * .02).toFixed(3)})` : `rgba(17,24,39,${(.03 + r() * .03).toFixed(3)})`);
    let html = '';
    for (let i = 0; i < circles; i++) {
      const s = 56 + r() * 190, ring = i % 2 === 0;
      html += `<span class="shp ${ring ? 'ring' : 'circle'}" style="--l:${(r() * 92).toFixed(1)}%;--t:${(r() * 86).toFixed(1)}%;--s:${s.toFixed(0)}px;--c:${colour(i)};--dx:${((r() - .5) * 110).toFixed(0)}px;--dy:${((r() - .5) * 110).toFixed(0)}px;--rot:${((r() - .5) * 40).toFixed(0)}deg;--dur:${(18 + r() * 22).toFixed(1)}s;--delay:-${(r() * 20).toFixed(1)}s"></span>`;
    }
    for (let i = 0; i < lines; i++) {
      html += `<span class="shp line" style="--l:${(r() * 70).toFixed(1)}%;--t:${(r() * 90).toFixed(1)}%;--s:${(140 + r() * 220).toFixed(0)}px;--c:${colour(i + 1)};--dx:${((r() - .5) * 120).toFixed(0)}px;--dy:${((r() - .5) * 60).toFixed(0)}px;--rot:${((r() - .5) * 24).toFixed(0)}deg;--dur:${(20 + r() * 20).toFixed(1)}s;--delay:-${(r() * 20).toFixed(1)}s"></span>`;
    }
    el.innerHTML = html;
  });
  const io = new IntersectionObserver(es => es.forEach(e => e.target.querySelector(':scope > .ambient')?.classList.toggle('on', e.isIntersecting)), { rootMargin: '80px' });
  $$('.hero,.sec').forEach(s => io.observe(s));
}

/* ---------- animated section dividers ---------- */
function buildDividers() {
  const COL = { dark: '#111827', steel: '#F3F4F6', white: '#FFFFFF' };
  const slots = $$('.dv-slot'), io = new IntersectionObserver(es => es.forEach(e => {
    e.target.classList.toggle('vis', e.isIntersecting); if (e.isIntersecting) e.target.classList.add('in');
  }), { threshold: .25 });
  slots.forEach(s => {
    const type = s.dataset.dv, d = document.createElement('div');
    d.className = 'dv dv-' + type; d.setAttribute('aria-hidden', 'true');
    d.style.setProperty('--from', COL[s.dataset.from]); d.style.setProperty('--to', COL[s.dataset.to]);
    const dark = s.dataset.from === 'dark' || s.dataset.to === 'dark';
    d.style.setProperty('--ln', dark ? 'rgba(255,255,255,.3)' : 'rgba(17,24,39,.28)');
    if (type === 'line') d.innerHTML = '<span class="rail"></span><span class="cover"></span><span class="dot"></span>';
    else {
      let path = 'M0 40'; for (let i = 0; i < 4; i++) { const x = i * 600; path += `C${x + 200} 2 ${x + 400} 78 ${x + 600} 40`; }
      d.innerHTML = `<svg viewBox="0 0 2400 80" preserveAspectRatio="none"><path d="${path}L2400 80L0 80Z"/></svg>`;
    }
    s.replaceWith(d); io.observe(d);
  });
}

/* ---------- reveal on scroll ---------- */
function initReveal() {
  const io = new IntersectionObserver(es => es.forEach(e => { if (e.isIntersecting) { e.target.classList.add('in'); io.unobserve(e.target); } }), { threshold: .12, rootMargin: '0px 0px -40px 0px' });
  $$('.rv').forEach(el => io.observe(el));
}

/* ---------- header: compact on scroll + mobile menu ---------- */
function initHeader() {
  const h = $('.hdr'), b = $('#burger'), m = $('#mnav');
  const on = () => h.classList.toggle('compact', scrollY > 8); on(); addEventListener('scroll', on, { passive: true });
  const setOpen = o => { b.setAttribute('aria-expanded', o); b.setAttribute('aria-label', o ? 'Close menu' : 'Open menu'); m.hidden = !o; };
  b.addEventListener('click', () => setOpen(m.hidden));
  m.addEventListener('click', e => { if (e.target.closest('a')) setOpen(false); });
  addEventListener('keydown', e => { if (e.key === 'Escape' && !m.hidden) { setOpen(false); b.focus(); } });
  matchMedia('(min-width:1024px)').addEventListener('change', q => q.matches && setOpen(false));
}

/* ---------- sticky mobile bar: shows after the hero ---------- */
function initBar() {
  const bar = $('#bar'), hero = $('#hero'); document.body.classList.add('has-bar');
  let pastHero = false, onForm = false;
  const apply = () => bar.classList.toggle('show', pastHero && !onForm);
  new IntersectionObserver(([e]) => { pastHero = !e.isIntersecting && e.boundingClientRect.top < 0; apply(); }).observe(hero);
  /* the form section and footer already carry the CTA, so the bar steps aside */
  const seen = new Set();
  const io = new IntersectionObserver(es => { es.forEach(e => e.isIntersecting ? seen.add(e.target) : seen.delete(e.target)); onForm = seen.size > 0; apply(); });
  io.observe($('#quote')); io.observe($('footer'));
}

/* ---------- FAQ accordion ---------- */
function initFaq() {
  $('#faqList').addEventListener('click', e => {
    const btn = e.target.closest('button[aria-expanded]'); if (!btn) return;
    const open = btn.getAttribute('aria-expanded') !== 'true';
    btn.setAttribute('aria-expanded', open); btn.closest('.qa').classList.toggle('open', open);
  });
}

/* ---------- before / after slider ---------- */
function initBA() {
  const ba = $('#ba'), inp = $('#baRange');
  const set = () => { ba.style.setProperty('--p', inp.value + '%'); inp.setAttribute('aria-valuetext', `new disc on the left, worn disc from ${inp.value}% across`); };
  inp.addEventListener('input', set); set();
}

/* ---------- testimonials carousel (CSS scroll-snap) ---------- */
function initCarousel() {
  const track = $('#track'), prev = $('#prev'), next = $('#next'), live = $('#live');
  const cards = [...track.children], n = cards.length; let pv = 1, idx = 0, tm, lastAnnounce = '';
  const gap = 16, step = () => cards[0].getBoundingClientRect().width + gap;
  const behavior = () => reduceMotion() ? 'auto' : 'smooth';
  function setPv() { pv = Math.max(1, Math.round(+getComputedStyle(track).getPropertyValue('--pv')) || 1); }
  function update(announce) {
    idx = Math.min(Math.max(Math.round(track.scrollLeft / step()), 0), n - pv);
    prev.disabled = track.scrollLeft <= 2;
    next.disabled = track.scrollLeft + track.clientWidth >= track.scrollWidth - 2;
    const txt = pv === 1 ? `${idx + 1} of ${n}` : `${idx + 1} to ${idx + pv} of ${n}`;
    if (announce && txt !== lastAnnounce) { lastAnnounce = txt; live.textContent = `Showing review${pv > 1 ? 's' : ''} ${txt}`; }
  }
  track.addEventListener('scroll', () => { update(false); clearTimeout(tm); tm = setTimeout(() => update(true), 350); }, { passive: true });
  prev.addEventListener('click', () => track.scrollBy({ left: -step(), behavior: behavior() }));
  next.addEventListener('click', () => track.scrollBy({ left: step(), behavior: behavior() }));
  track.addEventListener('keydown', e => {
    if (e.key === 'ArrowRight') { e.preventDefault(); track.scrollBy({ left: step(), behavior: behavior() }); }
    if (e.key === 'ArrowLeft') { e.preventDefault(); track.scrollBy({ left: -step(), behavior: behavior() }); }
    if (e.key === 'Home') { e.preventDefault(); track.scrollTo({ left: 0, behavior: behavior() }); }
    if (e.key === 'End') { e.preventDefault(); track.scrollTo({ left: track.scrollWidth, behavior: behavior() }); }
  });
  const re = () => { setPv(); update(false); }; addEventListener('resize', re); re();
}

/* ==========================================================================
   5. QUOTE FORM  (one component, used in the modal AND the final section)
   ========================================================================== */
const STEP_FIELDS = { 1: ['reg', 'mileage'], 2: ['serviceType', 'serviceLocation', 'postcode', 'preferredDay', 'note'], 3: ['name', 'mobile', 'email', 'consent'] };
const DAYS = [['next', 'Next available'], ['week', 'This week'], ['flexible', 'Flexible']];
const SVC_LABEL = Object.fromEntries(SITE.serviceTypes.map(s => [s.v, s.label]));
const isGarageOnly = v => !!SITE.serviceTypes.find(s => s.v === v)?.garageOnly;
const fmtReg = v => { const s = QuoteRequestSchema.normReg(v); return s.length > 4 ? s.slice(0, s.length - 3) + ' ' + s.slice(-3) : s; };

function createQuoteForm(root, prefix) {
  const blank = () => ({ reg: '', mileage: '', serviceType: '', serviceLocation: 'garage', postcode: '', preferredDay: 'next', note: '', name: '', mobile: '', email: '', consent: false });
  const st = { step: 1, view: 'form', busy: false, data: blank(), errors: {}, pkg: null, result: null, netMsg: '' };
  const id = n => `${prefix}-${n}`;

  const errHtml = f => st.errors[f] ? `<div class="ferr" id="${id('e-' + f)}" role="alert">${ico('alert')}<span>${esc(st.errors[f][0])}</span></div>` : '';
  const bad = f => st.errors[f] ? ' bad' : '';
  const inv = f => st.errors[f] ? ` aria-invalid="true" aria-describedby="${id('e-' + f)}"` : '';

  function header() {
    const titles = { 1: 'Your vehicle', 2: 'What do you need?', 3: 'Your details' };
    return `
      <h3 class="qf-h" id="${id('Title')}">Get your free itemised quote</h3>
      <p class="qf-sub">Takes 60 seconds. We'll call you within the hour.</p>
      <div class="qf-meta"><span>Step ${st.step} of 3</span><span>${titles[st.step]}</span></div>
      <div class="prog" role="progressbar" aria-label="Quote progress" aria-valuemin="1" aria-valuemax="3" aria-valuenow="${st.step}"><i style="--v:${st.step / 3}"></i></div>`;
  }

  function step1() {
    const d = st.data;
    return `<div class="qf-step" data-step="1">
      <h4 tabindex="-1" id="${id('sh')}">Your vehicle</h4>
      <div class="f${bad('reg')}"><label for="${id('reg')}">Vehicle registration</label>
        <div class="plate"><span class="strip" aria-hidden="true"><i></i>GB</span>
          <input id="${id('reg')}" data-f="reg" type="text" autocomplete="off" autocapitalize="characters" spellcheck="false" maxlength="8" placeholder="ENTER REG" value="${esc(d.reg)}"${inv('reg')}></div>
        ${errHtml('reg')}</div>
      <div class="f${bad('mileage')}"><label for="${id('mileage')}">Approximate mileage <span class="opt-hint">(optional)</span></label>
        <input class="fin" id="${id('mileage')}" data-f="mileage" type="text" inputmode="numeric" autocomplete="off" placeholder="For example 68,000" value="${esc(d.mileage)}"${inv('mileage')}>
        ${errHtml('mileage')}</div>
    </div>`;
  }

  function step2() {
    const d = st.data, garageOnly = isGarageOnly(d.serviceType), mob = d.serviceLocation === 'mobile';
    return `<div class="qf-step" data-step="2">
      <h4 tabindex="-1" id="${id('sh')}">What do you need?</h4>
      ${st.pkg ? `<p class="pkgchip">${ico('file')}Package: ${esc(st.pkg.name)}, from ${esc(st.pkg.price)}</p>` : ''}
      <fieldset class="f${bad('serviceType')}"><legend>What do you need?</legend>
        <div class="opts two">${SITE.serviceTypes.map(s => `
          <div class="opt"><input type="radio" name="${id('svc')}" id="${id('svc-' + s.v)}" value="${s.v}" data-f="serviceType"${d.serviceType === s.v ? ' checked' : ''}${st.errors.serviceType ? ` aria-invalid="true" aria-describedby="${id('e-serviceType')}"` : ''}>
            <label for="${id('svc-' + s.v)}">${ico(s.icon)}<span>${esc(s.label)}</span></label></div>`).join('')}</div>
        ${errHtml('serviceType')}</fieldset>
      <fieldset class="f${bad('serviceLocation')}"><legend>Where would you like the work done?</legend>
        <div class="opts two">
          <div class="opt"><input type="radio" name="${id('loc')}" id="${id('loc-garage')}" value="garage" data-f="serviceLocation"${!mob ? ' checked' : ''}><label for="${id('loc-garage')}">${ico('car')}<span>Drop off at our garage<small>Armley, Leeds</small></span></label></div>
          <div class="opt"><input type="radio" name="${id('loc')}" id="${id('loc-mobile')}" value="mobile" data-f="serviceLocation"${mob ? ' checked' : ''}${garageOnly ? ' disabled' : ''}><label for="${id('loc-mobile')}">${ico('van')}<span>Mobile visit (we come to you)<small>Mon-Sat, by appointment</small></span></label></div>
        </div>
        <p class="help" id="${id('go')}" ${garageOnly ? '' : 'hidden'}>This one is done at our garage.</p>
        ${errHtml('serviceLocation')}</fieldset>
      <div class="f${bad('postcode')}" id="${id('pcw')}" ${mob ? '' : 'hidden'}><label for="${id('postcode')}">Postcode for the visit</label>
        <input class="fin" id="${id('postcode')}" data-f="postcode" type="text" autocomplete="postal-code" autocapitalize="characters" placeholder="For example LS12 3AB" maxlength="8" value="${esc(d.postcode)}"${inv('postcode')}>
        ${errHtml('postcode')}</div>
      <fieldset class="f"><legend>Preferred day</legend><div class="opts" style="grid-template-columns:repeat(3,minmax(0,1fr))">${DAYS.map(([v, l]) => `
        <div class="opt"><input type="radio" name="${id('day')}" id="${id('day-' + v)}" value="${v}" data-f="preferredDay"${d.preferredDay === v ? ' checked' : ''}><label for="${id('day-' + v)}" style="justify-content:center;text-align:center;padding:10px 6px">${l}</label></div>`).join('')}</div></fieldset>
      <div class="f${bad('note')}"><label for="${id('note')}">Anything we should know? <span class="opt-hint">(optional)</span></label>
        <textarea class="fin" id="${id('note')}" data-f="note" maxlength="520" placeholder="For example: grinding noise when I brake" rows="3"${inv('note')}>${esc(d.note)}</textarea>${errHtml('note')}</div>
    </div>`;
  }

  function step3() {
    const d = st.data;
    return `<div class="qf-step" data-step="3">
      <h4 tabindex="-1" id="${id('sh')}">Your details</h4>
      <div class="f${bad('name')}"><label for="${id('name')}">Your name</label><input class="fin" id="${id('name')}" data-f="name" type="text" autocomplete="name" value="${esc(d.name)}"${inv('name')}>${errHtml('name')}</div>
      <div class="f${bad('mobile')}"><label for="${id('mobile')}">Mobile number</label><input class="fin" id="${id('mobile')}" data-f="mobile" type="tel" inputmode="tel" autocomplete="tel" placeholder="07700 900123" value="${esc(d.mobile)}"${inv('mobile')}>${errHtml('mobile')}</div>
      <div class="f${bad('email')}"><label for="${id('email')}">Email <span class="opt-hint">(optional)</span></label><input class="fin" id="${id('email')}" data-f="email" type="email" inputmode="email" autocomplete="email" value="${esc(d.email)}"${inv('email')}>${errHtml('email')}</div>
      <div class="f${bad('consent')}"><label class="cons" for="${id('consent')}"><input type="checkbox" id="${id('consent')}" data-f="consent"${d.consent ? ' checked' : ''}${inv('consent')}><span>We'll only use your details to respond to your enquiry.</span></label>${errHtml('consent')}</div>
    </div>`;
  }

  function nav() {
    const last = st.step === 3;
    return `<div class="qf-nav">
      ${st.step > 1 ? '<button type="button" class="btn-text" data-act="back">Back</button>' : ''}
      ${last
        ? `<button type="submit" class="cta"${st.busy ? ' disabled' : ''}>${st.busy ? `${ico('loader', 'spin')} Sending your request` : 'Get Your Free Quote'}</button>`
        : '<button type="submit" class="btn-dark">Continue</button>'}
    </div>`;
  }

  function render() {
    if (st.view === 'success') return renderSuccess();
    if (st.view === 'error') return renderError();
    root.innerHTML = `<form class="qf" novalidate aria-labelledby="${id('Title')}">${header()}${st.step === 1 ? step1() : st.step === 2 ? step2() : step3()}${nav()}
      <p class="fine" style="margin-top:14px">Prototype: nothing you type here is sent or saved anywhere.</p></form>`;
    $$('.cta', root).forEach(b => { if (!b.querySelector('.cta-label')) b.innerHTML = `<span class="cta-glow" aria-hidden="true"></span><span class="cta-label">${b.innerHTML}</span>`; });
  }

  function renderSuccess() {
    const d = st.data, first = d.name.trim().split(/\s+/)[0];
    root.innerHTML = `<div class="qf"><div class="qf-state" role="status">
      <span class="big">${ico('check')}</span>
      <h4 tabindex="-1" id="${id('Title')}">Thanks ${esc(first)}, Marcus's team will call you within the hour.</h4>
      <p>We'll talk through what you need and send an itemised quote before any work starts.</p>
      <span class="demo-lbl">${ico('info')}Demonstration only: no data was sent.</span>
      <dl class="summary">
        <div><dt>Vehicle</dt><dd>${esc(fmtReg(d.reg))}</dd></div>
        <div><dt>Job</dt><dd>${esc(SVC_LABEL[d.serviceType] || '')}${st.pkg ? ' (' + esc(st.pkg.name) + ')' : ''}</dd></div>
        <div><dt>Where</dt><dd>${d.serviceLocation === 'mobile' ? 'Mobile visit, ' + esc(d.postcode.toUpperCase()) : 'Our garage, Armley'}</dd></div>
        <div><dt>Reference</dt><dd>${esc(st.result?.reference || '')}</dd></div>
      </dl>
      <div class="qf-nav" style="margin-top:18px"><button type="button" class="btn-text" data-act="again">Start another quote</button></div></div></div>`;
  }

  function renderError() {
    root.innerHTML = `<div class="qf"><div class="qf-state">
      <h4 tabindex="-1" id="${id('Title')}">That didn't go through</h4>
      <div class="errbox" role="alert">${ico('alert')}<div><h4>Request not sent</h4><p>${esc(st.netMsg)}</p></div></div>
      <div class="qf-nav" style="margin-top:20px"><button type="button" class="btn-text" data-act="edit">Check my details</button><button type="button" class="btn-dark" data-act="retry">Try again</button></div></div></div>`;
  }

  function focusHeading() { const h = $('#' + CSS.escape(id('sh')), root) || $('[tabindex="-1"]', root); h && h.focus({ preventScroll: false }); }
  function focusFirstInvalid() {
    const el = $('[aria-invalid="true"]', root); if (el) { el.focus(); return; } focusHeading();
  }

  function validateStep(n) {
    const res = QuoteRequestSchema.safeParse({ ...st.data, packageInterest: st.pkg?.name });
    st.errors = {};
    if (!res.success) STEP_FIELDS[n].forEach(f => { if (res.error.fieldErrors[f]) st.errors[f] = res.error.fieldErrors[f]; });
    return Object.keys(st.errors).length === 0;
  }

  async function submit() {
    st.busy = true; st.errors = {}; render(); $('.cta', root)?.focus();
    const res = await submitQuote({ ...st.data, packageInterest: st.pkg?.name });
    st.busy = false;
    if (res.status === 'success') { st.result = res; st.view = 'success'; render(); $('[tabindex="-1"]', root)?.focus(); toast('Quote request received. Demonstration only: no data was sent.'); }
    else if (res.status === 'validation_error') {
      st.errors = res.fieldErrors; st.step = [1, 2, 3].find(n => STEP_FIELDS[n].some(f => st.errors[f])) || 3; st.view = 'form'; render(); focusFirstInvalid();
    } else { st.netMsg = res.message; st.view = 'error'; render(); $('[tabindex="-1"]', root)?.focus(); }
  }

  /* keep location/postcode in sync without re-rendering (so focus is not lost) */
  function syncLocation() {
    const go = isGarageOnly(st.data.serviceType), mobileRadio = $('#' + CSS.escape(id('loc-mobile')), root);
    if (!mobileRadio) return;
    if (go && st.data.serviceLocation === 'mobile') st.data.serviceLocation = 'garage';
    mobileRadio.disabled = go;
    $('#' + CSS.escape(id('loc-garage')), root).checked = st.data.serviceLocation === 'garage';
    mobileRadio.checked = st.data.serviceLocation === 'mobile';
    $('#' + CSS.escape(id('go')), root).hidden = !go;
    $('#' + CSS.escape(id('pcw')), root).hidden = st.data.serviceLocation !== 'mobile';
  }
  function clearErr(f) {
    if (!st.errors[f]) return; delete st.errors[f];
    $('#' + CSS.escape(id('e-' + f)), root)?.remove();
    const el = root.querySelector(`[data-f="${f}"]`); el?.removeAttribute('aria-invalid'); el?.removeAttribute('aria-describedby'); el?.closest('.f')?.classList.remove('bad');
  }

  root.addEventListener('input', e => {
    const t = e.target, f = t.dataset?.f; if (!f || t.type === 'radio' || t.type === 'checkbox') return;
    if (f === 'reg') { t.value = t.value.toUpperCase().replace(/[^A-Z0-9 ]/g, ''); }
    if (f === 'postcode') t.value = t.value.toUpperCase();
    st.data[f] = t.value; clearErr(f);
  });
  root.addEventListener('change', e => {
    const t = e.target, f = t.dataset?.f; if (!f) return;
    if (t.type === 'checkbox') st.data[f] = t.checked; else if (t.type === 'radio') st.data[f] = t.value;
    clearErr(f); if (f === 'serviceType') { clearErr('serviceLocation'); st.pkg = st.pkg && t.value === 'service' ? st.pkg : null; syncLocation(); const chip = $('.pkgchip', root); if (chip && !st.pkg) chip.remove(); }
    if (f === 'serviceLocation') { syncLocation(); if (t.value === 'mobile') $('#' + CSS.escape(id('postcode')), root)?.focus(); }
  });
  root.addEventListener('submit', e => {
    e.preventDefault(); if (st.busy) return;
    if (!validateStep(st.step)) { render(); focusFirstInvalid(); return; }
    if (st.step < 3) { st.step++; render(); focusHeading(); } else submit();
  });
  root.addEventListener('click', e => {
    const a = e.target.closest('[data-act]'); if (!a) return;
    const act = a.dataset.act;
    if (act === 'back') { st.step = Math.max(1, st.step - 1); st.errors = {}; render(); focusHeading(); }
    if (act === 'retry') { st.view = 'form'; st.step = 3; submit(); }
    if (act === 'edit') { st.view = 'form'; st.step = 3; render(); focusHeading(); }
    if (act === 'again') { reset(); render(); focusHeading(); }
  });

  function reset() { st.step = 1; st.view = 'form'; st.busy = false; st.data = blank(); st.errors = {}; st.pkg = null; st.result = null; }
  render();

  return {
    /** Pre-fill from a CTA. Generic CTAs keep whatever the visitor already typed. */
    preset(p = {}) {
      if (st.view === 'success') reset();
      st.view = st.view === 'error' ? 'form' : st.view; st.step = 1; st.errors = {};
      if (p.reg) st.data.reg = QuoteRequestSchema.normReg(p.reg).slice(0, 8);
      if (p.service) { st.data.serviceType = p.service; st.pkg = null; }
      if (p.pkg) { st.pkg = p.pkg; st.data.serviceType = 'service'; }
      if (p.location) st.data.serviceLocation = p.location;
      if (p.note && !st.data.note) st.data.note = p.note;
      if (isGarageOnly(st.data.serviceType) && st.data.serviceLocation === 'mobile') st.data.serviceLocation = 'garage';
      render();
    },
    focusStart() { const el = $('input, textarea', root); el ? el.focus() : focusHeading(); },
    reset() { reset(); render(); },
  };
}

/* ---------- toast ---------- */
let toastTm;
function toast(msg) {
  const t = $('#toast'); $('#toastTx').textContent = msg; t.classList.add('show');
  clearTimeout(toastTm); toastTm = setTimeout(() => t.classList.remove('show'), 5200);
}

/* ---------- modal + CTA wiring ---------- */
function initQuote() {
  const modal = $('#modal'), dlg = $('.dialog', modal), modalForm = createQuoteForm($('#modalForm'), 'modal');
  createQuoteForm($('#inlineForm'), 'inline');
  const backdrop = [$('main'), $('.hdr'), $('footer'), $('#bar'), $('#wa')];
  let lastTrigger = null;

  function open(preset, trigger) {
    lastTrigger = trigger || document.activeElement; modalForm.preset(preset);
    modal.hidden = false; document.documentElement.classList.add('lock'); backdrop.forEach(el => el && el.setAttribute('inert', ''));
    dlg.setAttribute('aria-labelledby', 'modal-Title'); dlg.scrollTop = 0;
    requestAnimationFrame(() => modalForm.focusStart());
  }
  function close() {
    modal.hidden = true; document.documentElement.classList.remove('lock'); backdrop.forEach(el => el && el.removeAttribute('inert'));
    lastTrigger && lastTrigger.focus && lastTrigger.focus({ preventScroll: true });
  }
  modal.addEventListener('click', e => { if (e.target.closest('[data-close]')) close(); });
  addEventListener('keydown', e => {
    if (modal.hidden) return;
    if (e.key === 'Escape') { e.preventDefault(); close(); return; }
    if (e.key === 'Tab') {
      const f = $$('button:not([disabled]),input:not([disabled]),textarea,select,a[href],[tabindex]:not([tabindex="-1"])', dlg).filter(el => el.offsetParent !== null || el === document.activeElement);
      if (!f.length) return; const first = f[0], last = f[f.length - 1];
      if (e.shiftKey && (document.activeElement === first || !dlg.contains(document.activeElement))) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && (document.activeElement === last || !dlg.contains(document.activeElement))) { e.preventDefault(); first.focus(); }
    }
  });

  /* every CTA and entry-point opens the same form */
  document.addEventListener('click', e => {
    const b = e.target.closest('[data-quote]'); if (!b) return;
    const d = b.dataset, pkg = d.package ? (SITE.packages || []).find(p => p.id === d.package) : null;
    open({ service: d.service, pkg, location: d.location, note: d.note }, b);
  });

  /* hero reg-plate: lenient UK validation, empty allowed */
  const form = $('#regForm'), input = $('#heroReg'), err = $('#heroRegErr');
  input.addEventListener('input', () => { input.value = input.value.toUpperCase().replace(/[^A-Z0-9 ]/g, ''); err.hidden = true; });
  form.addEventListener('submit', e => {
    e.preventDefault();
    const reg = QuoteRequestSchema.normReg(input.value);
    if (reg && !/^[A-Z0-9]{2,8}$/.test(reg)) {
      err.innerHTML = `${ico('alert')}<span>That doesn't look like a UK reg. Try something like LS16 ABC, or leave it blank.</span>`; err.hidden = false; input.focus(); return;
    }
    err.hidden = true; open({ reg }, form.querySelector('.cta'));
  });
}

/* ==========================================================================
   6. Boot
   ========================================================================== */
renderStatic();
enhanceCTAs();
buildAmbient();
buildDividers();
initReveal();
initHeader();
initBar();
initFaq();
initBA();
initCarousel();
initQuote();
})();
</script>
</body>
</html>
