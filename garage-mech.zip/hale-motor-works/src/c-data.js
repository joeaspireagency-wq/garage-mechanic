<script>
(() => {
'use strict';
document.documentElement.classList.add('js');

/* ==========================================================================
   1. SITE CONFIG  (src/data/site.ts equivalent)
   Everything customer-facing lives here, so the template can be re-badged
   for another UK garage. All prices, reviews and guarantees are PLACEHOLDERS.
   ========================================================================== */
const SITE = {
  brand: {
    name: 'Hale Motor Works', label: 'Garage & Mobile Mechanics',
    tagline: 'Honest garage. Fair prices. Fixed right the first time.',
    phone: '+44 7340 849530', phoneHref: '+447340849530', email: 'hello@halemotorworks.example',
    owner: 'Marcus Hale', base: 'Armley, Leeds', est: 2012,
  },
  trust: [
    { label: 'DVSA Approved MOT Test Station' },
    { label: 'Motor Ombudsman Service & Repair Code' },
    { label: 'Trading Standards Approved' },
  ],

  /* order matters: matches the quote form radio cards */
  serviceTypes: [
    { v: 'mot',         label: 'MOT',                          icon: 'cal',     garageOnly: true },
    { v: 'service',     label: 'Service',                      icon: 'wrench' },
    { v: 'brakes',      label: 'Brakes',                       icon: 'disc' },
    { v: 'diagnostics', label: 'Warning light or diagnostics', icon: 'pulse' },
    { v: 'clutch',      label: 'Clutch or timing belt',        icon: 'wrench',  garageOnly: true },
    { v: 'battery',     label: "Battery or won't start",       icon: 'battery' },
    { v: 'unsure',      label: 'Not sure',                     icon: 'help' },
  ],

  symptoms: [
    { title: 'MOT is due',                      text: 'An honest test, with no surprise failures.',          icon: 'cal',     service: 'mot' },
    { title: 'Warning light is on',             text: 'We find the fault, not just clear the code.',          icon: 'alert',   service: 'diagnostics' },
    { title: 'Brakes squealing or grinding',    text: 'We show you the wear before we fix anything.',         icon: 'disc',    service: 'brakes' },
    { title: 'Strange noise or poor handling',  text: "Not sure what it is? We'll find out and tell you.",    icon: 'sound',   service: 'unsure' },
    { title: "Car won't start or flat battery", text: 'Battery fitted at our garage or at your door.',        icon: 'battery', service: 'battery' },
    { title: 'Service is overdue',              text: 'Interim, full or major. Itemised first.',              icon: 'wrench',  service: 'service' },
  ],

  services: [
    { icon: 'cal', title: 'MOT test', tag: 'Garage', benefit: 'Quick, honest MOTs with no surprise failures.',
      features: ['DVSA-approved test lane (placeholder)', 'Free or reduced-fee partial retest within 10 working days where applicable', "Text reminder before next year's MOT"],
      from: '£40', note: 'MOT fees are capped by law. Ours is at or below the maximum (placeholder).' },
    { icon: 'wrench', title: 'Servicing', tag: 'Garage or mobile', tagIcon: 'van', benefit: 'Interim, full and manufacturer-schedule servicing.',
      features: ['Digital health check with photos', 'Quality parts, fully itemised', 'Service book stamped'], from: '£129' },
    { icon: 'disc', title: 'Brakes & tyres', tag: 'Garage, brakes also mobile', tagIcon: 'van', benefit: "Stop safely, with only the work that's needed.",
      features: ['Free brake inspection', 'Pads and discs fitted and road-tested', 'Tyres supplied and fitted at the garage'], from: '£189', unit: 'per axle, pads and discs' },
    { icon: 'pulse', title: 'Diagnostics & warning lights', tag: 'Garage or mobile', tagIcon: 'van', benefit: 'Warning light on? We find the fault, not just clear the code.',
      features: ['Full diagnostic scan', 'Plain-English explanation', 'Fault priced before any repair'], from: '£55' },
    { icon: 'wrench', title: 'Clutch & timing belt', tag: 'Garage', benefit: 'Bigger jobs, fixed price.',
      features: ['Inspection and fixed price quote', 'Quality parts and warranty', 'Same-week booking where possible'], quoted: 'Quoted per vehicle' },
    { icon: 'van', title: 'Mobile mechanic', tag: 'We come to you', tagIcon: 'van', mobile: true, benefit: 'Same honest service, at your home or work.',
      features: ['Servicing, brakes, batteries and diagnostics on site', 'Same itemised quote, photos and warranty', 'Fully equipped van, Mon-Sat by appointment'], from: '£79', unit: 'call-out (placeholder)' },
  ],

  included: [
    'Itemised quote before any work starts', 'We call before any extra work', 'Photos of any faults we find',
    'Old parts shown on request', 'Quality parts, fitted properly', 'Warranty on parts and labour',
    'Clear invoice, no hidden extras',
  ],




  areas: ['Leeds', 'Bradford', 'Wakefield', 'Pudsey', 'Morley', 'Horsforth'],

  reviews: [
    { name: 'Chloe B.', town: 'Armley, Leeds', job: 'MOT',         where: 'Garage', text: 'Booked an MOT and they found a blown bulb, fixed it while I waited for a few quid. No fuss, no upselling.' },
    { name: 'Raj P.',   town: 'Bradford',      job: 'Full service', where: 'Garage', text: 'Itemised quote came by text with photos. Everything I paid for was exactly what Marcus said it would be.' },
    { name: 'Karen L.', town: 'Wakefield',     job: 'Brakes',       where: 'Garage', text: 'My brakes were squealing. Marcus showed me the worn pads on his phone and only did what was needed.' },
    { name: 'Dean S.',  town: 'Pudsey',        job: 'Clutch',       where: 'Garage', text: 'Fixed price quoted for the clutch and it came in exactly on price. Car drives like new.' },
    { name: 'Fiona M.', town: 'Morley',        job: 'Diagnostics',  where: 'Mobile', text: 'Warning light had been on for months. Jamie came to my house, found the faulty sensor within the hour and explained it in plain English.' },
    { name: 'Tom H.',   town: 'Horsforth',     job: 'Battery and service', where: 'Mobile', text: "Car wouldn't start at work. The van arrived within a couple of hours and fitted a new battery in the car park. Booked my service with them straight after." },
  ],

  faqs: [
    { q: "How do I know I won't be overcharged or sold work I don't need?", a: "You get an itemised quote before we start, photos of any fault we find, and a phone call before anything extra is added. If it doesn't need doing, we won't do it, and we'll show you the old parts if you ask." },
    { q: 'Will the price change once you start?', a: 'Only if you say yes. If we find something else, we call you with the cost first, and nothing is done until you approve it.' },
    { q: 'What happens if my car fails its MOT?', a: 'We explain exactly what failed and give you an itemised quote to fix it. Partial retest rules apply, often free or reduced-fee within 10 working days (placeholder wording).' },
    { q: 'How long will it take, and can I get my car back the same day?', a: 'Most MOTs take under an hour and most services are done the same day. For mobile visits we agree a time slot with you and usually finish on the spot.' },
    { q: "Will servicing at an independent garage affect my car's warranty?", a: "Servicing at an independent garage shouldn't void a new-car warranty as long as the work follows the manufacturer's schedule and uses the correct quality of parts. Always check your own warranty terms (placeholder wording)." },
    { q: 'What if something goes wrong after the job?', a: "Our work is covered by a 12-month / 12,000-mile warranty on parts and labour, garage or mobile. If it isn't right, we'll come back and put it right." },
    { q: 'Can a mobile mechanic really do the same job as a garage?', a: "For most servicing, brakes, batteries and diagnostics, yes. Our van carries professional tools and diagnostic equipment, uses the same quality parts, and gives you the same itemised quote and warranty. MOTs and bigger jobs like clutches are done at our garage, and we'll tell you honestly which is best." },
  ],
};

/* ==========================================================================
   2. IMAGE REGISTRY  (src/data/images.ts equivalent)
   id, alt, width, height, focal point + a render() that returns the artwork.
   In a real build each entry points at /public/images/... via next/image;
   here the artwork is inline SVG so the page is fully self-contained.
   To swap in real photos: replace render() with an <img src="..."> string.
   ========================================================================== */
const svgOpen = (w, h, label, par = 'xMidYMid slice') =>
  `<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${w} ${h}" preserveAspectRatio="${par}" role="img" aria-label="${label}">`;

function heroSVG(alt) {
  let slats = ''; for (let y = 58; y < 292; y += 14) slats += `<path d="M312 ${y}H548" stroke="#2c374b" stroke-width="2"/>`;
  let peg = ''; for (let y = 74; y < 244; y += 18) for (let x = 40; x < 254; x += 18) peg += `<circle cx="${x}" cy="${y}" r="1.5" fill="#3a475e"/>`;
  const spanner = (x, h, c) => `<g transform="translate(${x} 84)"><rect x="-4" y="14" width="8" height="${h}" rx="4" fill="${c}"/><circle cy="10" r="10" fill="none" stroke="${c}" stroke-width="6"/></g>`;
  return `${svgOpen(600, 480, alt)}
<defs>
 <linearGradient id="hw-wall" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#2b3548"/><stop offset="1" stop-color="#182030"/></linearGradient>
 <linearGradient id="hw-floor" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#3d4759"/><stop offset="1" stop-color="#1f2736"/></linearGradient>
 <linearGradient id="hw-car" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#dbe3ee"/><stop offset="1" stop-color="#8fa0b8"/></linearGradient>
 <radialGradient id="hw-glow" cx=".5" cy=".1" r=".9"><stop offset="0" stop-color="#fff" stop-opacity=".34"/><stop offset="1" stop-color="#fff" stop-opacity="0"/></radialGradient>
 <linearGradient id="hw-glass" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#334155"/><stop offset="1" stop-color="#0f172a"/></linearGradient>
</defs>
<rect width="600" height="480" fill="url(#hw-wall)"/>
<rect x="300" y="40" width="260" height="254" rx="4" fill="#1a2230" stroke="#0e1522" stroke-width="3"/>${slats}
<rect x="24" y="52" width="244" height="200" rx="8" fill="#202a3a" stroke="#334158" stroke-width="2"/>${peg}
${spanner(60, 70, '#b4bfd0')}${spanner(90, 54, '#9aa8bd')}${spanner(120, 82, '#b4bfd0')}${spanner(150, 62, '#9aa8bd')}
<g transform="translate(182 100)"><rect width="9" height="60" rx="3" fill="#DC2626"/><rect y="56" width="9" height="30" fill="#9aa8bd"/></g>
<g transform="translate(206 100)"><rect width="9" height="50" rx="3" fill="#111827" stroke="#475569"/><rect y="46" width="9" height="34" fill="#9aa8bd"/></g>
<rect x="46" y="178" width="92" height="52" rx="6" fill="#0f1623" stroke="#475569" stroke-width="2"/><rect x="52" y="184" width="80" height="34" rx="3" fill="#1d4ed8" opacity=".75"/>
<rect x="80" y="8" width="150" height="10" rx="5" fill="#f8fafc"/><rect x="380" y="8" width="150" height="10" rx="5" fill="#f8fafc"/>
<ellipse cx="155" cy="120" rx="150" ry="160" fill="url(#hw-glow)"/><ellipse cx="455" cy="120" rx="150" ry="170" fill="url(#hw-glow)"/>
<rect y="372" width="600" height="108" fill="url(#hw-floor)"/>
<path d="M0 372H600" stroke="#0e1522" stroke-width="3"/>
<path d="M20 440H580" stroke="#e5e7eb" stroke-opacity=".28" stroke-width="3" stroke-dasharray="26 18"/>
<ellipse cx="400" cy="400" rx="190" ry="14" fill="#000" opacity=".35"/>
<g><rect x="338" y="236" width="14" height="156" fill="#475569"/><rect x="438" y="236" width="14" height="156" fill="#475569"/>
<rect x="322" y="388" width="46" height="9" rx="2" fill="#2f3b4d"/><rect x="422" y="388" width="46" height="9" rx="2" fill="#2f3b4d"/>
<rect x="338" y="300" width="14" height="10" fill="#DC2626"/><rect x="438" y="300" width="14" height="10" fill="#DC2626"/>
<rect x="296" y="284" width="196" height="7" rx="3" fill="#64748b"/></g>
<g transform="translate(214 176)">
 <circle cx="82" cy="110" r="34" fill="#070a11"/><circle cx="268" cy="110" r="34" fill="#070a11"/>
 <path d="M6 104V86c0-12 10-18 24-20l68-6C112 36 130 22 160 22h62c24 0 44 18 60 38l44 8c14 3 20 14 20 28v8c0 4-4 6-8 6H10c-2 0-4-2-4-6z" fill="url(#hw-car)"/>
 <path d="M112 58C122 42 136 32 156 32h40v26z" fill="url(#hw-glass)"/><path d="M204 32h18c16 0 30 12 44 26h-62z" fill="url(#hw-glass)"/>
 <path d="M200 32V104" stroke="#6b7a90" stroke-width="2"/><rect x="170" y="70" width="18" height="4" rx="2" fill="#6b7a90"/><rect x="220" y="70" width="18" height="4" rx="2" fill="#6b7a90"/>
 <rect x="334" y="78" width="12" height="9" rx="2" fill="#fde68a"/><rect x="6" y="80" width="7" height="12" rx="2" fill="#DC2626"/>
 <path d="M6 98H346" stroke="#000" stroke-opacity=".15"/>
 <g><circle cx="82" cy="110" r="30" fill="#0b0f19"/><circle cx="82" cy="110" r="18" fill="#a8b4c6"/><circle cx="82" cy="110" r="6" fill="#475569"/><path d="M82 94v32M66 110h32M71 99l22 22M93 99l-22 22" stroke="#64748b" stroke-width="3"/></g>
 <g><circle cx="268" cy="110" r="30" fill="#0b0f19"/><circle cx="268" cy="110" r="18" fill="#a8b4c6"/><circle cx="268" cy="110" r="6" fill="#475569"/><path d="M268 94v32M252 110h32M257 99l22 22M279 99l-22 22" stroke="#64748b" stroke-width="3"/></g>
</g>
<g transform="translate(140 396)">
 <ellipse cx="0" cy="2" rx="38" ry="7" fill="#000" opacity=".35"/>
 <rect x="-22" y="-92" width="18" height="90" rx="5" fill="#2a364b"/><rect x="4" y="-92" width="18" height="90" rx="5" fill="#2f3b52"/>
 <rect x="-26" y="-10" width="24" height="10" rx="3" fill="#0b0f19"/><rect x="2" y="-10" width="24" height="10" rx="3" fill="#0b0f19"/>
 <rect x="-32" y="-176" width="64" height="90" rx="16" fill="#3b4c6b"/>
 <path d="M0 -172V-92" stroke="#243047" stroke-width="2"/><rect x="-22" y="-156" width="18" height="9" rx="2" fill="#DC2626"/>
 <rect x="-46" y="-170" width="15" height="68" rx="7" fill="#33435f"/><circle cx="-39" cy="-98" r="7" fill="#dfb08c"/>
 <path d="M26 -166 36 -132 52 -128" stroke="#33435f" stroke-width="14" stroke-linecap="round" fill="none"/>
 <g transform="rotate(-8 50 -140)"><rect x="34" y="-158" width="38" height="28" rx="4" fill="#0b1220" stroke="#94a3b8" stroke-width="2"/><rect x="38" y="-154" width="30" height="20" rx="2" fill="#60a5fa" opacity=".9"/><path d="M42 -146h18M42 -140h12" stroke="#fff" stroke-opacity=".7" stroke-width="2"/></g>
 <circle cx="50" cy="-130" r="6" fill="#dfb08c"/>
 <rect x="-7" y="-196" width="14" height="22" fill="#d2a07b"/>
 <circle cx="0" cy="-208" r="19" fill="#e3b690"/>
 <path d="M-19 -212C-20 -232 -4 -230 2 -230 18 -230 21 -218 19 -210 14 -218 4 -220 -4 -220-10 -220-16 -216-19 -212z" fill="#2d2f36"/>
 <circle cx="-6" cy="-206" r="2" fill="#1f2937"/><circle cx="8" cy="-206" r="2" fill="#1f2937"/><path d="M-5 -196Q2 -190 9 -196" stroke="#8a4b34" stroke-width="2" fill="none" stroke-linecap="round"/>
</g>
<g><rect x="36" y="296" width="112" height="100" rx="6" fill="#1f2937" stroke="#334158" stroke-width="2"/><rect x="30" y="288" width="124" height="12" rx="4" fill="#DC2626"/>
<path d="M40 322H144M40 348H144M40 374H144" stroke="#0e1522" stroke-width="3"/><rect x="82" y="306" width="26" height="5" rx="2" fill="#94a3b8"/><rect x="82" y="332" width="26" height="5" rx="2" fill="#94a3b8"/><rect x="82" y="358" width="26" height="5" rx="2" fill="#94a3b8"/></g>
<g><rect x="522" y="342" width="72" height="18" rx="9" fill="#0b0f19" stroke="#1f2937"/><rect x="522" y="360" width="72" height="18" rx="9" fill="#0b0f19" stroke="#1f2937"/><rect x="522" y="378" width="72" height="18" rx="9" fill="#0b0f19" stroke="#1f2937"/></g>
</svg>`;
}

function vanSVG(alt) {
  const house = (x, brick, door) => `<g transform="translate(${x} 0)"><rect x="0" y="70" width="78" height="130" fill="${brick}"/><rect x="0" y="62" width="78" height="10" fill="#374151"/>
   <rect x="10" y="86" width="24" height="30" fill="#f8fafc" opacity=".92"/><rect x="46" y="86" width="22" height="30" fill="#f8fafc" opacity=".92"/><path d="M10 101H34M22 86V116" stroke="${brick}" stroke-width="2"/>
   <rect x="44" y="140" width="24" height="60" rx="2" fill="${door}"/><rect x="10" y="140" width="24" height="26" fill="#f8fafc" opacity=".85"/></g>`;
  return `${svgOpen(400, 250, alt)}
<defs><linearGradient id="vn-sky" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#cbd5e1"/><stop offset="1" stop-color="#eef2f7"/></linearGradient>
<linearGradient id="vn-body" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="#dfe4ec"/></linearGradient>
<clipPath id="vn-clip"><path d="M80 205V132q0-10 10-10h158q8 0 14 8l24 34h32q12 0 12 12v29z"/></clipPath></defs>
<rect width="400" height="250" fill="url(#vn-sky)"/>
<ellipse cx="80" cy="34" rx="60" ry="14" fill="#fff" opacity=".7"/><ellipse cx="300" cy="24" rx="70" ry="12" fill="#fff" opacity=".6"/>
${house(-10, '#8b5a4a', '#1e3a5f')}${house(68, '#7c4f41', '#7f1d1d')}${house(146, '#94614f', '#14532d')}${house(224, '#85543f', '#1e3a5f')}${house(302, '#8b5a4a', '#7f1d1d')}${house(380, '#7c4f41', '#14532d')}
<rect y="200" width="400" height="14" fill="#a8b0bc"/><rect y="214" width="400" height="36" fill="#464f5e"/><path d="M0 214H400" stroke="#d1d5db" stroke-width="3"/>
<ellipse cx="205" cy="222" rx="140" ry="8" fill="#000" opacity=".3"/>
<path d="M80 205V132q0-10 10-10h158q8 0 14 8l24 34h32q12 0 12 12v29z" fill="url(#vn-body)"/>
<g clip-path="url(#vn-clip)"><rect x="70" y="170" width="280" height="7" fill="#DC2626"/><rect x="70" y="177" width="280" height="30" fill="#111827"/></g>
<text x="96" y="152" font-family="'Barlow Condensed',Arial Narrow,sans-serif" font-weight="700" font-size="25" letter-spacing=".5" fill="#111827">HALE MOTOR WORKS</text>
<text x="97" y="165" font-family="Inter,Arial,sans-serif" font-weight="600" font-size="8" letter-spacing="2" fill="#4B5563">MOBILE MECHANICS · LEEDS</text>
<path d="M252 134h14q6 0 10 6l16 22h-40z" fill="#1e293b"/><path d="M256 138h8l12 18h-20z" fill="#475569" opacity=".5"/>
<path d="M108 126V205" stroke="#c4cad6" stroke-width="2"/><rect x="236" y="172" width="12" height="3" rx="1.5" fill="#9aa3b2"/>
<path d="M92 118H236M104 118V110M224 118V110" stroke="#4B5563" stroke-width="3"/><rect x="98" y="106" width="132" height="4" rx="2" fill="#4B5563"/>
<rect x="326" y="178" width="8" height="8" rx="2" fill="#fde68a"/><rect x="80" y="178" width="5" height="10" rx="1" fill="#DC2626"/>
<g><circle cx="130" cy="207" r="22" fill="#0b0f19"/><circle cx="130" cy="207" r="12" fill="#cbd5e1"/><circle cx="130" cy="207" r="4" fill="#64748b"/></g>
<g><circle cx="292" cy="207" r="22" fill="#0b0f19"/><circle cx="292" cy="207" r="12" fill="#cbd5e1"/><circle cx="292" cy="207" r="4" fill="#64748b"/></g>
</svg>`;
}

function marcusSVG(alt) {
  return `${svgOpen(400, 500, alt)}
<defs><linearGradient id="mc-bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#3a4558"/><stop offset="1" stop-color="#1a2230"/></linearGradient>
<linearGradient id="mc-skin" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="#e2b78f"/><stop offset="1" stop-color="#cd9b78"/></linearGradient></defs>
<rect width="400" height="500" fill="url(#mc-bg)"/>
<rect x="30" y="60" width="150" height="230" rx="6" fill="#222c3d" opacity=".9"/><rect x="230" y="40" width="140" height="260" rx="6" fill="#273246" opacity=".9"/>
<path d="M30 130H180M30 190H180M230 120H370M230 200H370" stroke="#35425a" stroke-width="3"/>
<circle cx="70" cy="40" r="26" fill="#fff" opacity=".08"/><circle cx="330" cy="70" r="40" fill="#fff" opacity=".06"/><circle cx="210" cy="30" r="18" fill="#fff" opacity=".09"/>
<path d="M30 500C30 410 80 368 148 352L252 352C320 368 370 410 370 500z" fill="#2f3b52"/>
<path d="M148 352L200 412 252 352 232 346 200 380 168 346z" fill="#e5e7eb"/><path d="M148 352L200 430 172 500H30C30 410 80 368 148 352z" fill="#34445f"/><path d="M252 352L200 430 228 500H370C370 410 320 368 252 352z" fill="#34445f"/>
<rect x="246" y="420" width="76" height="26" rx="4" fill="#DC2626"/><text x="284" y="438" text-anchor="middle" font-family="Inter,Arial,sans-serif" font-weight="700" font-size="12" letter-spacing="1" fill="#fff">MARCUS</text>
<rect x="76" y="424" width="64" height="14" rx="3" fill="#111827" opacity=".5"/>
<rect x="172" y="294" width="56" height="70" rx="10" fill="#c99876"/>
<ellipse cx="136" cy="236" rx="10" ry="18" fill="#cd9b78"/><ellipse cx="264" cy="236" rx="10" ry="18" fill="#cd9b78"/>
<ellipse cx="200" cy="232" rx="64" ry="78" fill="url(#mc-skin)"/>
<path d="M136 222C130 164 166 150 200 150s70 14 64 72C258 192 244 180 200 180s-58 12-64 42z" fill="#3a3d45"/>
<path d="M150 170C166 160 184 158 200 158" stroke="#6b7280" stroke-width="3" fill="none" stroke-linecap="round" opacity=".7"/>
<path d="M141 252C148 304 252 304 259 252 252 278 148 278 141 252z" fill="#5b4a3f" opacity=".5"/>
<path d="M178 288Q200 300 222 288" stroke="#7c3f2e" stroke-width="3.5" fill="none" stroke-linecap="round"/><path d="M182 288Q200 298 218 288Q200 305 182 288z" fill="#fff" opacity=".9"/>
<ellipse cx="172" cy="232" rx="8" ry="5" fill="#fff"/><ellipse cx="228" cy="232" rx="8" ry="5" fill="#fff"/><circle cx="173" cy="233" r="3.2" fill="#2b2118"/><circle cx="227" cy="233" r="3.2" fill="#2b2118"/>
<path d="M158 217Q172 209 186 216M214 216Q228 209 242 217" stroke="#3a3d45" stroke-width="5" fill="none" stroke-linecap="round"/>
<path d="M198 236 194 264 204 266" stroke="#b07f60" stroke-width="3" fill="none" stroke-linecap="round" stroke-linejoin="round"/>
<path d="M160 242Q168 248 176 242M224 242Q232 248 240 242" stroke="#b07f60" stroke-width="2" fill="none" opacity=".6"/>
</svg>`;
}

function brakeSVG(isAfter, alt) {
  const p = isAfter ? 'ba' : 'bb';
  const cx = 250, cy = 240;
  let rings = '';
  for (let r = 70; r <= 146; r += 7) rings += `<circle cx="${cx}" cy="${cy}" r="${r}" fill="none" stroke="${isAfter ? '#ffffff' : '#000000'}" stroke-opacity="${isAfter ? .25 : .22}" stroke-width="${!isAfter && r % 21 === 0 ? 3 : 1.2}"/>`;
  let bolts = '';
  for (let i = 0; i < 5; i++) { const a = i * 72 * Math.PI / 180 - Math.PI / 2; bolts += `<circle cx="${(cx + 33 * Math.cos(a)).toFixed(1)}" cy="${(cy + 33 * Math.sin(a)).toFixed(1)}" r="6" fill="${isAfter ? '#d1d5db' : '#74604f'}"/>`; }
  const rust = isAfter ? '' : `<ellipse cx="190" cy="150" rx="40" ry="14" fill="#b4592b" opacity=".45"/><ellipse cx="320" cy="300" rx="34" ry="18" fill="#a0522d" opacity=".5"/><ellipse cx="170" cy="310" rx="26" ry="10" fill="#c2672f" opacity=".4"/><circle cx="${cx}" cy="${cy}" r="148" fill="none" stroke="#7a3f1d" stroke-width="7" opacity=".5"/>`;
  const pad = (h, col) => `<g transform="translate(434 236)"><rect x="0" y="${-h}" width="116" height="${h}" fill="${col}"/><rect x="0" y="0" width="116" height="14" rx="2" fill="#9ca3af"/><path d="M0 14H116" stroke="#6b7280"/></g>`;
  return `${svgOpen(640, 480, alt)}
<defs>
 <linearGradient id="${p}-bg" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#2d3748"/><stop offset="1" stop-color="#151b27"/></linearGradient>
 <radialGradient id="${p}-disc" cx=".4" cy=".35" r=".8">${isAfter
   ? '<stop offset="0" stop-color="#f3f4f6"/><stop offset=".55" stop-color="#cbd5e1"/><stop offset="1" stop-color="#8b98ab"/>'
   : '<stop offset="0" stop-color="#8f786a"/><stop offset=".6" stop-color="#6a4e40"/><stop offset="1" stop-color="#3b3434"/>'}</radialGradient>
</defs>
<rect width="640" height="480" fill="url(#${p}-bg)"/>
<path d="M0 410H640" stroke="#0b0f19" stroke-width="3"/><rect y="410" width="640" height="70" fill="#10151f"/>
<circle cx="${cx}" cy="${cy}" r="150" fill="url(#${p}-disc)"/>${rings}${rust}
${isAfter ? `<path d="M120 190A140 140 0 0 1 250 100" stroke="#fff" stroke-opacity=".7" stroke-width="6" fill="none" stroke-linecap="round"/>` : ''}
<circle cx="${cx}" cy="${cy}" r="56" fill="${isAfter ? '#1f2937' : '#4a433d'}"/><circle cx="${cx}" cy="${cy}" r="56" fill="none" stroke="${isAfter ? '#9ca3af' : '#6b5a4d'}" stroke-width="3"/>${bolts}<circle cx="${cx}" cy="${cy}" r="14" fill="#0b0f19"/>
<rect x="330" y="150" width="96" height="180" rx="18" fill="${isAfter ? '#DC2626' : '#6b3b2f'}"/><rect x="342" y="170" width="72" height="20" rx="6" fill="#000" opacity=".18"/><circle cx="378" cy="210" r="9" fill="${isAfter ? '#fecaca' : '#8a6a5c'}"/><circle cx="378" cy="270" r="9" fill="${isAfter ? '#fecaca' : '#8a6a5c'}"/>
${isAfter ? pad(34, '#1f2937') : pad(7, '#4b362d')}
<text x="492" y="270" text-anchor="middle" font-family="ui-monospace,Menlo,monospace" font-size="12" letter-spacing="2" fill="#e5e7eb">${isAfter ? 'NEW PAD' : 'WORN PAD'}</text>
</svg>`;
}

const IMAGES = {
  hero:        { id: 'hero',        width: 600, height: 480, focal: '50% 60%', alt: 'Illustration of a technician with a diagnostic tablet beside a car raised on a lift in a clean four-bay workshop', render() { return heroSVG(this.alt); } },
  van:         { id: 'van',         width: 400, height: 250, focal: '50% 60%', alt: 'Dark blue mobile mechanic van parked on a Leeds residential street', render() { return `<img src="data:image/jpeg;base64,/*VAN_PHOTO*/" alt="${this.alt}" width="960" height="600" style="display:block;width:100%;height:100%;object-fit:cover">`; } },
  marcus:      { id: 'marcus',      width: 400, height: 500, focal: '50% 40%', alt: 'Marcus Hale, MOT tester and owner, at work under a bonnet', render() { return `<img src="data:image/jpeg;base64,/*OWNER_PHOTO*/" alt="${this.alt}" width="800" height="1000" style="display:block;width:100%;height:100%;object-fit:cover">`; } },
  brakeBefore: { id: 'brakeBefore', width: 640, height: 480, focal: '40% 50%', alt: 'Before: a rusty, heavily worn brake disc and caliper', render() { return `<img src="data:image/jpeg;base64,/*BRAKE_BEFORE*/" alt="${this.alt}" width="1100" height="821" draggable="false">`; } },
  brakeAfter:  { id: 'brakeAfter',  width: 640, height: 480, focal: '40% 50%', alt: 'After: a new clean brake disc fitted', render() { return `<img src="data:image/jpeg;base64,/*BRAKE_AFTER*/" alt="${this.alt}" width="1100" height="821" draggable="false">`; } },
};
