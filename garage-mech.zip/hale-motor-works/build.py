"""Assembles index.html from src/ (single self-contained page; photos are inlined as base64).
Usage:  python3 build.py
"""
import pathlib
root = pathlib.Path(__file__).resolve().parent
p = root / 'src'
html = ''.join((p / f).read_text() for f in ['a-head.html', 'b-body.html', 'c-data.js', 'd-app.js'])
for marker, f in [('/*HERO_PHOTO*/', 'hero-photo.b64'), ('/*VAN_PHOTO*/', 'van-photo.b64'),
                  ('/*OWNER_PHOTO*/', 'owner-photo.b64'), ('/*BRAKE_AFTER*/', 'brake-after.b64'),
                  ('/*BRAKE_BEFORE*/', 'brake-before.b64'), ('/*REVIEW_BADGE*/', 'review-badge.b64')]:
    html = html.replace(marker, (p / f).read_text().strip())
(root / 'index.html').write_text(html)
print(f'index.html written ({len(html)//1024} KB)')
